ML-Agents es una herramienta bastante conocida. Fue la primera que empezó con la explosión del Reinforcement Learnig. Es una toolkit que integra un plugin para Unity y un par de aplicaciones para 
Limitaciones:
	1. Solo tiene los algoritmos: ppo, sac, poca.
	2. Te limita la personalización de los agentes a las opciones que permite los archivos de configuración (ver  [Training Configuration File](https://github.com/Unity-Technologies/ml-agents/blob/develop/docs/Training-Configuration-File.md)) en comparación con otras herramientas que permiten el uso de cualquier librería de Python.
Ventajas: 
 1. Unity es una herramienta como mucho recorrido y por tanto con gran cantidad de documentación facilitando su aprendizaje.
ML-Agents requiere:
1. Unity
2. Visual Studio Code
3. El paquete de ml-agents
## Set up
Este tuturial esta basado en el de la pagina de [github](https://github.com/Unity-Technologies/ml-agents/blob/develop/docs/Installation.md). Se le han hecho algunas modificaciones para que funcione.
1. Instalar Unity Hub (ver [aqui](https://unity.com/download))
2. Desde Unity Hub descargar el editor de Unity. En este proyecto se ha usado la versión 2022.3.15f1.
3. Clonar el repositorio de ML-Agents en un repositorio de confianza:
```shell
git clone --branch release_20 https://github.com/Unity-Technologies/ml-agents.git
```
4. Instalar Python 3.9. Se recomienda usar conda:
```shell
conda create -n mlagents python=3.9.12 && conda activate mlagents
```
5. Para Windows hay que instalar *torch* por separado en nuestro entorno:
```shell
pip3 install torch~=1.13.1 -f https://download.pytorch.org/whl/torch_stable.html
```
6. Instalar ml-agents.Ir al directorio donde se ha clonado el repositorio. Intalar primero *ml-agents-envs* y despues *ml-agents*.
```shell
cd /path/to/ml-agents
python -m pip install ./ml-agents-envs
python -m pip install ./ml-agents
```
7. Si todo ha salido bien, la consola, en la que tienes el entorno activo, debería reconocerte la aplicación *mlagents-learn*. Escribe el comando:
```shell
mlagents-learn --help
```
Debiera reconocerla aunque te podría salir un error que te sugire reducir la versión del paquete *protobuf*.
8. Si te ha salido el error baja la versión de *protobuf* a la 3.20 y repite el lanzamiento anteriror. El error se debiera arreglar y aparecer una lista de todos los argumentos que acepta el comando.
```shell
pip install protobuf==3.20
```
### Activar plugin
Cada vez que empieces un proyecto en Unity de RL deberás instalar el paquete ml-agents. Para ello sigue los siguientes pasos:
1. Crea un proyecto de Unity.
2. Habré la ventana Proyect Manager (*Window>Proyect Manager*).
3. En la ventana *Proyect Manager* selcecione *Add Package from disk*(*+>Add Package from disk*).
4. Se habrira el explorador de archivos. Naveque hasta donde tiene clonado el repositorio y en abra la carpeta *com.unity.ml-agents*. Seleccione el archivo *json* de nombre *package*. Ya tiene en el proyecto el plugin.
![[ML Agents/Imagenes/Captura2.png]]
## Siguientes Pasos
Sigua el tutorial [[Unity CartPole]] para diseñar un cart-pole rapidamente en Unity.
## Anexo de problemas
Al seguir los tutoriales de instalacion han surgido los primeros de muchos problemas:
1. Si clonas la reléase que te dice el tutorial de instalación (Realise 21) no puedes seguir el primer tutorial que este necesita el paquete *Barracuda*, y el la 21 han abandonado ese y han pasado a *Sentis*. Esto quiere decir que el *Realise 21* no esta completamente actualizado. No se sabe si para el resto de usos y tutoriales el 21 da problemas. Recomendamos el 20. Este problema se da en la instalación del plugin ML-Agents en Unity.
2.  Además en la instalación de los paquetes en nuestro enviroment de Python surgen problemas de compatibilidad de versiones entre Python y numpy (paquete que necesita ml-agents). Una posible solución a ello bajar la versiion de Python a 3.9, pero la 21 necesita de Python 3.10. Para solucionarlos se ha utilizado en el entorno de python la 20 con python 3.9. Es ha permitido la correcta instalación de los paquetes ml-agents y ml-agents-envs.
3. Un vez la instalado los paquetes, el entorno ya reconocía el nuevo comando *mlagents-learn* pero había errores en su ejecución. Siguiendo la sugerencia del display del error se ha reducido la versión del paquete *protobuf* de la 4.23.4 (instalada por defecto)a la 3.20. Este cambio a permitido el funcionamiento de la aplicación.
**Nota**: Aparentemente, al ser el mismo repositorio de github pero realese diferentes, tiene características compatibles. Esto se ha descubierto, sin querer, cuando utilizando un Entorno de Python con la 20, se han utilizado documentos de configuración de la 21 para preparar un servidor desde donde se entrenara un entorno en Unity con el plugin de la 20. 
ML-agents solo tiene PPO, POCA, SAC