En este documento diseñaremos un cart-pole en untiy.
1. Anadir una rail. Desde la ventana *Hierarchy* *click derecho>3D Object>Cube* o en la barra de herramientas superior *GameComponent>3D object > Cube*. Cambiar el nombre a "Rail". Cambiar el tamaño cambiando la propiedad de la escala: en la venta *Inspector* *Transform>Scale> X : 2, Y: 0.05, Z: 0.05*. Asegurarse que sus propiedades de posición y rotación estén a todos los valores a 0. En el *Inspector* añadirle un componente *RigidBody*: *Add Component>RigidBody*.
2. Repetir el paso anterior para el cart y el pole:
	1. Cart: Nombre "Cart", Escala 0.2 0.2 0.2 Posición y rotación a cero. Añadir RigidBody
	2. Pole: Nombre "Pole", Escala 0.2 0.5 0.01, Posición 0 0.25 0.105, Rotación a cero. Añadir RigidBody.
3. Añadir junta entre el Cart y el Rail. En Unity no hay prismatic joint almennos que la crees a través de un *Articulation Body*. Por eso tuneamos un junta general. En el *Inspector* del *Cart* añadir un componente *Configurable Joint*. En su propiedad *Connected Body*, arrastrar desde la ventana *Hierarchy* el objeto *Rail* hasta la propiedad. En las seis propiedades acabadas en *Motion* cambiar su valor a *Locked* menos la de *X Motion* que debiera estar en *Free*.
4. Añadri junta entre el Pole y el Cart. En el *Pole* añadir componente *Hinge Joint*. A la propiedad *Conected body* arrastrar el objeto *Cart*. Cambiar la propiedad *Anchor*  a X: 0 Y: -0.5 Z: -0.5 (define la posición de la junta localmente, depende de la escala que habíamos definido en el polo). Cambiar la propiedad *Axis* a X: 0 Y: 0 Z: 1 (define el eje de giro).
5. Dejar estático el *Rail*. Selecciona el *Rail* y haz check sobre la propiedad *RigieBody>Is Kinetic*. Esta opción hace que el rail no puedan afectarle fuerzas impidiendo que caiga por la gravedad y se mueva por la inercia.
6. Mover la camara y testear. En el objeto *Main Camera* cambiar las propiedades: Position 0 0.5 2 y Rotation 180 0 180. Darle a play. Autamaticamente cambiara a la ventana game, la cual muestra la escena desde el punto de vista d ela camara. Cambia a la ventana *Scene*, selecciona el carta y desplazarlo ligeramente  a lo largo del Eje X. Se debiera ver oscilar el polo y desplazarse el cart. Hasta el momento se debiera ver todo así: ![[ML Agents/Imagenes/Captura3.png]]
7. Anidar el polo en un objeto vacío. Lo usaremos como pivote para facilitar el script necesario para girar el polo desde el extremo. Crea un objeto vacío (*GameObject>Create Empty*) y llámalo *PivotPole*. Reinicia la posiciones del polo. Anida el *Pole* en el *PivotPole*. Desplaza el *Pole* 0.25 en Y. Desplaza el *PivotPole* 0.105 en Z.
## Scripting
El entono esta acabado. Ahora vamos a hacer el scripting. Vamos ha añadir dos scripts del paquete de ml-agents y crear uno propio. Todos los scripts se suelen añadir al objeto de la escena que represente al agente. En nuestro caso será el cart. Previamente hay que instalar el paquete de ml-agents.
1. Seleccionar el *Cart* y añadir el componente *Behavior Parameters*. En este componente modificar las siguiente propiedades: *Behavior Name*: CartPole, *Vector Observation>Space Size*: 4, *Actions>Continous Actions*: 1, *Actions>Discrete Branches*: 0.
2. Seleccionar el Cart y añadir el componente *Decision Requester*.
3. Seleccionar el *Cart* y añadir un script con nombre CartCtrl. En la ventana *Proyect* en la carpeta *Assets* se debiera haber creado el Script.
Ahora toca hacer la clase análoga a la que seria un entrono en python.
1. Abrir el script CartCtrl desde la ventana *Proyect*. Se abrirá en Visual Studio. Puede ser que Visual Studio pueda que instales el paquete de unity.
2. Lo primero es añadir los paquetes que usaremos:
```c#
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
```
3. Despues cambiaremos la clse de la que herada este script. Cambiar *Monobehaviour* por *Agent*.
4. No nos hará falta el método *Update*. Borrarlo.
5. Para controlar el cart necesitamos hacernos con su RigidBody. Añadir el siguiente codigo:
```c#
Rigidbody CartJoint;
void Start()
{
    CartJoint = GetComponent<Rigidbody>();
}
```
6. Vamos a sobrecargar el método *OnEpisodeBegin*. Este método se llama cuando el episodio acaba. Es el clasico *reset*. En el reseteamos el *cart* y el polo. Adicionalmente hay que inicializar variables publicas para que se conviertan en propiedades en la ventana del *Inspector*. Añadir el siguiente codigo:
```c#
float InicialAngle;
public Transform PolePivot;
public Transform Pole;
public Rigidbody PoleJoint;
public override void OnEpisodeBegin()
{
	    // MOVE Cart TO INICIAL POSITION
    this.CartJoint.angularVelocity = Vector3.zero;
    this.CartJoint.velocity = Vector3.zero;
    this.transform.localPosition = Vector3.zero;


    // MOVE Pole TO INICIAL ANGLE
    InicialAngle = Random.value * 20 - 10;
    PoleJoint.angularVelocity = Vector3.zero;
    PoleJoint.velocity = Vector3.zero;
    Pole.localPosition = new Vector3 (0, 0.25f, 0);
    Pole.localEulerAngles = Vector3.zero;
    PolePivot.localEulerAngles = new Vector3(0,0,InicialAngle);
}
```
7. Ahora añadimos el método sobrecargado de generar la observaciones (*CollectObservations*).
```c#
public override void CollectObservations(VectorSensor sensor)
{
    // Cart and Pole positions
    sensor.AddObservation(this.transform.localPosition.x);
    sensor.AddObservation(Pole.transform.localEulerAngles.z);

    // Cart and Pole velocity
    sensor.AddObservation(CartJoint.velocity.x);
    sensor.AddObservation(PoleJoint.angularVelocity.z);
}
```
8. Toca sobrecargar el metodo de ejecutar las acciones y calcular las recompensas (*OnActionReceived*).
```c#
public float forceMultiplier = 10;
public override void OnActionReceived(ActionBuffers actionBuffers)
{
    // Actions, size = 2
    Vector3 controlSignal = Vector3.zero;
    controlSignal.x = actionBuffers.ContinuousActions[0];
    CartJoint.AddForce(controlSignal * forceMultiplier);

    // Rewards
    float AngleToEqui;
    if (Pole.localEulerAngles.z > 180)
    {
        AngleToEqui = 360 - Pole.localEulerAngles.z - InicialAngle;
    }
    else
    {
        AngleToEqui = Pole.localEulerAngles.z - InicialAngle;
    }
    print("Observaciones");
    print("Angulo al de equilibrio");
    print(AngleToEqui);

    // Reached target
    if (AngleToEqui > 90)
    {
        print("Superado 90");
        SetReward(-10.0f);
        EndEpisode();
    }else
    {
        SetReward(1 - AngleToEqui/90);
    }
}
```
9. Vamos a añadir un metodo para dar control humano del *Cart* y testearlo antes de intentar entrenarlo.
```c#
public override void Heuristic(in ActionBuffers actionsOut)
{
    var continuousActionsOut = actionsOut.ContinuousActions;
    continuousActionsOut[0] = -Input.GetAxis("Horizontal");
}  
```
10. Antes de testearlo hay que dar valor a todas las propiedades publicas que hemos añadido (cuado guardes el script en Visual Studio debieran aparecer en el Unity, en la ventana de *Inspector*, en el componente del script, al tener seleccionado el *Cart*):
	1. Arrastrar el objeto *PivotPole*  a la propiedad *PivotPole*.
	2. Arrastrar el objeto *Pole*  a la propiedad *Pole*
	3. Arrastrar el objeto *Pole*  a la propiedad *PoleJoint*.
11. Testear. En el Cart cambia la protiedad *Behavior Parameters>Behavior Type* a *Heuristic only*. Dale a play. Controla el *cart* con las teclas A-D o con las flechas Izq-Dch.
Una vez que funciona solo queda crear el archivo .yml de configuracion de la política y lanzar el entrenamiento. 
1. Crea el archivo *CartPole_config.yml* con el siguiente contenido:
```yml
behaviors:
  CartPole:
    trainer_type: ppo
    hyperparameters:
      batch_size: 10
      buffer_size: 100
      learning_rate: 3.0e-4
      beta: 5.0e-4
      epsilon: 0.2
      lambd: 0.99
      num_epoch: 3
      learning_rate_schedule: linear
      beta_schedule: constant
      epsilon_schedule: linear
    network_settings:
      normalize: false
      hidden_units: 128
      num_layers: 2
    reward_signals:
      extrinsic:
        gamma: 0.99
        strength: 1.0
    max_steps: 300000
    time_horizon: 64
    summary_freq: 10000
```
2. Abre una consola y activa en entorno de ml-agents. Navega hasta donde has creado el archivo de configuración y ejecuta la siguiente linea:
```shell
mlagents-learn CartPole_config.yml --run-id=CartPole
```
3. Se configurara todo y pedirá que le des a play en Unity. Antes de ello asegúrate de que la propiedad de *Behavior Type* no esta en *Heuristic only*. Una vez le des a play en la consola aparecerá todos los parámetros definidos en la configuraron y empezara el entrenamiento. Irán apareciendo displays con el desarrollo de este.
4. Cuando el entrenamiento acabe o se cancele (si se cancela y la consola no se ha cerrado puedes continuarlo llamando de nuevo a la linea anterio y añadiendo *--resume*) se guardara se guardara el archivo con nombre *CartPole.onnx*. El archivo se habrá guardado en "./results/CartPole". Este es nuestro modelo.
5. Para testearlo copia el archivo a la carpeta *Assets* de Unity, en la ventana *Proyect*. Después arrastra ese nuevo *Asset* a la propiedad *Behavior Parameters>Model* del Cart. Dale a play.
6. Vamos a ver el desarrollo del entrenamiento con la siguiente lineal. Abrir en el explorado el puerto del local host que indique:
```shell
tensorboard --logdir results
```
## Extra
En Unity no puedes escalar la gravedad de los RigidBody  a diferencia de en otros entorno. Es interesante hacerlo en este experimento para facilitar el entrenamiento o el control humano. Por ello vamos a hacer un sricpt para ello.
1. Haz CheckOut a la propiedad *RigidBody>Enable Gravity* del Pole. 
2. En Pole crea el siguiente script con nombre GravityCtrl. Es generigo por lo que lo puedes añadir a cualquier *GameObject* que contenga un RigidBody.
```c#
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityCrl : MonoBehaviour
{
    Rigidbody rbody;
    public float gravityScale = 1.0f;

    // Global Gravity doesn't appear in the inspector. Modify it here in the code
    // (or via scripting) to define a different default gravity for all objects.
    public static float globalGravity = -9.81f;
    // Start is called before the first frame update
    void Start()
    {
        rbody = GetComponent<Rigidbody>();
        rbody.useGravity = false;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 gravity = globalGravity * gravityScale * Vector3.up;
        rbody.AddForce(gravity, ForceMode.Acceleration);
    }
}
```
Con este script puedes controlar la escala de la gravedad que le afecta al objeto que lo contenga.
