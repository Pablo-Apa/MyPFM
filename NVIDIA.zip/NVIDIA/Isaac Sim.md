En este documento veremos que es Isaac Sim, como instalarlo y como es su UI.
Isaac Sim es una aplicación de simulación Robótica. Ofrece diversas herramientas incluso también para RL. Isaac Sim en si misma es un herramienta muy potente pero tiene requerimientos altos.
Entre las principales características que tiene es que su lenguage de progamacion es Python. Al instalarlo, se instala con un entorno de Python 3.7 que contiene paquetes para sus propias Api ([documentacion](https://docs.omniverse.nvidia.com/isaacsim/latest/reference_python_api.html)). Entre las distintas extensiones y kits que vienen por defecto esta el kit de gym. Entre varias cosas aporta un wrapper para encapsular entornos y hacerlos compatibles con gymnasium.
Hay que mencionar a Isaac Gym. Isaac Gym es un herramienta de Nvidia que esta en desarrollo y que se basa en Isaac Sim para aplicar Reinforcement learning. Se puede descargar el pre lanzamiento pero solo esta disponible para **Ubuntu**([enlace](https://developer.nvidia.com/isaac-gym)). 
Ademas hay otros dos documentos que son los tutoriales para diseñar y entrenar un Cart Pole. Son [[Isaac Sim CartPole Desing]] y [[Isaac Sim Task & Train]]. Hay que seguirlos en el orden presentado.
## Setup
1. Instalar *Omniverse Launcher* ([aqui](https://www.nvidia.com/es-es/omniverse/download/)). Es necesario registrarse. Seleccionar la opción gratuita.
2. Lanzar la aplicación *Omniverse Launcher*. En la ventana *Enchange* buscar "Isaac Sim" y descargar la aplicación.
Tiene requerimientos altos, sobre todo de grafica:
![[NVIDIA/Imagenes/Captura1.png]]
## Python Enviroment
Isaac Sim te permite hacer uso de su entorno de python con Visual Studio o crear un entorno en Conda. Por supuesto también lo puedes utilizar directamente desde la consola. También puedes ejecutar scripts desde la aplicación.
Al usarlo con VS surgen errores. Se intenta conectar al entorno pero no puede.
Cuando creas un entorno con conda se te instalan múltiples paquetes para hacer uso de la GPU pero no se te instalan las APIs de Isaac Sim.
Por tanto se recomienda escribir los script en VS o parecido, pues tiene una interfaz mas amigable. Y después lanzar los scripts desde la consola o desde el *Script Editor* de Isaac Sim.
Para ejecutar scripts o instalar nuevos paquetes hay que utilizar el documento *python.bat* que se encuentra en el directorio donde se instalo Isaac Sim. Se muestra ejemplos en [[Isaac Sim Task & Train]].
## User Interface
La interfaz grafica  de Isaac Sim es muy parecida a la de programas similares. Todos las pestañas/ventanas se pueden cambiar de sitio y tamaño. Además de que se pueden habilitar nuevas en el menú de *Windows*. En este apartado repasaremos las principales.
En la siguiente imagen se muestra UI por defecto (casi por defecto; tiene abierto el script editor) al lanzar la aplicación.
![[NVIDIA/Imagenes/Captura3.PNG]]
Las principales ventanas por defecto son:
1. **Viewport**: Es la vista de la escena 3D. Tiene diversas opciones para cambiar la perspectiva (ej: la de una cámara de la escena), ver distinta información (ej: colliders) entre otros. Además permite hacer trasformaciones de posición y orientación. Puedes añadir otro *Viewport* en el despegable *Window* del menú. En el ejemplo de la imagen se muestra un cart-pole
	![[NVIDIA/Imagenes/Captura6.PNG]]
2. **Stage**: Muestra una lista y jerarquía de los elementos que componen la escena. Desde esa misma ventana se pueden añadir nuevos elementos o propiedades a los ya existentes entre otras opciones. En el ejemplo de la imagen se muestra los prim que componen el CartPole
	![[NVIDIA/Imagenes/Captura5.PNG]]
3. **Property**: Muestra las propiedades de la prim seleccionada en *Stage*. Permite modificarlas o añadir nuevas.
	![[NVIDIA/Imagenes/Captura7.PNG]]
4. **Console**: En la consola. Puedes decidir que muestra (errores, advertencia o información). Es común que muestre warnings continuamente
	![[NVIDIA/Imagenes/Captura8.PNG]]
5. **Content**: Es un explorador de archivos. Facilita añadir elemtos  que ya hubiera creado. En el ejemplo de la imagen he navegado hasta el directorio donde tengo guardados mi proyectos.
	![[NVIDIA/Imagenes/Captura13.PNG]]
6. **Isaac Assets (Beta)**: Son los recursos que te da Isaac Sim estandar. Viene unos cuantos robots.
	![[NVIDIA/Imagenes/Captura9.PNG]]
Además también hay un par que puedes abrir en la barra del menú, en el despegable *Windows*:
1. **Script editor**: Permite crear y abrir scripts de python. Ademas permite lanzarlos en el entorno estándar de Isaac Sim.
	![[NVIDIA/Imagenes/Captura10.PNG]]
2. **Action Graph**: Es un herramienta que permite hacer scripts de forma grafica. Se habre en *Window>Visual Scripting>Action Graph*. No se ha utilizado en los tutoriales.
	![[NVIDIA/Imagenes/Captura11.PNG]]