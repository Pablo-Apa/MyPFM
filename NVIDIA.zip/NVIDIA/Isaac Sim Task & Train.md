En este documento veremos los scripts necesarios para hacer un experimento de RL. Isaac Sim Gym extensión tiene múltiples ejemplos RL.. Para usarlos y experimentar con ellos ver la documentación [aqui](https://docs.omniverse.nvidia.com/isaacsim/latest/isaac_gym_tutorials/index.html). Además la extensión esta construida sobre [rl_games](https://github.com/Denys88/rl_games). Esta es una librería de RL de Python que tiene limitaciones en los algoritmos disponibles (principalmente PPO)
Para crear un experimento en RL se creara una clase heredada de *BaseTask*. Esta es una clase dirigida al control simulaciones de Isaac Sim (ver [*What is a Task?*](https://docs.omniverse.nvidia.com/isaacsim/latest/core_api_tutorials/tutorial_core_adding_manipulator.html?highlight=task#what-is-a-task)). A la clase que creemos se le pasara a un wrapper del kit de gym de Isaac Sim. Este creara un entorno compatible con gymnasium, y por tanto también con paquetes RL de Python como *stable-baselines3*.
## Instalar *stable-baselines3*
 El primer paso es instalar *stable-baselines 3* (sb3) en el entorno de Python de Isaac Sim. Para ello abrir una consola del sistema y guardar como variable (PYTHON_PATH) la ruta al ejecutable de Python. Este se encontrara en el directorio de instalación de Isaac Sim. Para acceder a el se pude lanzar Isaac Sim dese el lanzador de *Omniverse*. Cuando se lanza aparecerá una ventana emergente con opciones de lanzado. Seleccionar el botón *Open in File Browser*.
 ![[NVIDIA/Imagenes/Captura2.png]]
 La ruta debiera se parecida a la mostrada a continuación:
```shell
doskey PYTHON_PATH=C:\Users\user\AppData\Local\ov\pkg\isaac_sim-*\python.bat $*
```
La ruta se utilizara también para ejecutar los scripts, aparte de para instalar paquetes de Python. 
Para instalar sb3 ejecutar la siguiente linea en la consola:
```shell
PYTHON_PATH -m pip install stable-baselines3
```
## RL scripts
Los scripts son hechos en base al diseño de Cart-Pole hecho en [[Isaac Sim CartPole Desing]]. Veremos tres scripts para el experimento RL:
1. *cartpole_task.py*: Define la clase heredada de *BaseTask* que utilizaremos para controlar el cart-pole.
2. *cartpole_train.py*: hace uso de la clase definida en *cartpole_task*. La encapsula en en un entorno compatible con gym para entrenar a un agente con sb3.
3. *cartpole_play.py*: testea el modelo entrenado en *cartpole_train.py*
El tutorial para estos scripts esta [aqui](https://docs.omniverse.nvidia.com/isaacsim/latest/isaac_gym_tutorials/tutorial_gym_new_rl_example.html#creating-cartpole-task). Básicamente hay que copiar el código y hacerles unas pequeñas modificaciones.
Al tutorial hay que hacerle un par de modificaciones:
1. En el primer script, en el método *set_up_scene* hay que cambiar el *usd_path* al de nuestro cartpole. 
```python
# Borrar estas lineas
assets_root_path = get_assets_root_path()
usd_path = assets_root_path + "/Isaac/Robots/Cartpole/cartpole.usd
# Añadir 
usd_path = "/Path/To/My/*.usd"
```
2. Otras modificaciones como los nombres de las juntas. En nuestro caso nuestras juntas tiene nombres ligeramente diferentes al cartpole por defecto. En el metodo *post_reser(self)*:
```python
#Modificar estas lineas:
self._cart_dof_idx = self._cartpoles.get_dof_index("cartJoint")
self._pole_dof_idx = self._cartpoles.get_dof_index("poleJoint")
#Y convertirlas en esta otras lineas:
self._cart_dof_idx = self._cartpoles.get_dof_index("CartJoint")
self._pole_dof_idx = self._cartpoles.get_dof_index("PoleJoint")
```
Además hay algunos atributos, como *_reset_distance*, que no son necesarios debido a que a nuestro modelo de cartpole ya le habíamos añadido limites a las juntas. Para nuestro modelo, ese atributo se puede obviar. Además los códigos están hechos de forma mas o menos genérica. Por ejemplo, la task da pie a crear mas entornos al tener un atributo *num_envs* pero no esta del todo generalizado y se debiera hacer algunas modificaciones al código para que funcionara con mas de un entorno. Entre otras modificaciones estaría integrar un bucle en el método del setup para instanciar vario entornos. Otra modificación seria en los métodos que devuelven las observaciones y las recompensas. En esos métodos se crean variables de tipo *Tensor* y después llaman al método *item()* para transformarlas  en números de Python estándar. Si tuviéramos varios entornos habría que llamar al método *tolist()*, pues los tensores no serian de tamaño 1.
