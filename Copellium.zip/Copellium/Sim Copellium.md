Sim Copellium tiene tres versiones disponibles: player, edu, pro. La version utilizada el la de estudiantes (edu), que contiene todas las capacidades pero no se puede usar para usos comerciales.
