Por defecto copelias sim habre una serie de servers pos los que eschucha.
Por defecto con la descarga de Copelliam Sim se descargan, entre otros muchos recursos, unos bindings para controlar distintos elementos de copeliasm sim.
Para utlizarlos:
1. En el directorio donde se desarrolle el proyecto tener los archivos:
	1. sim.py
	2. simConst.py
	3. remoteApi.dll
sim.py es el archivo principal que "traduce" los bindings de python a funciones de C/C++ contenidas en remoteApi.dll. También hace uso de simConst.py como biblioteca de constantes. 
Los dos primeros archivos se encontraran en: 
	"../CoppeliaRobotics/CoppeliaSimEdu/programming/legacyRemoteApi/remoteApiBindings/python/python"  iniciando la ruta desde el directorio donde se instalo Coppelia.
El tercer archivo esta en 
	"../CoppeliaRobotics/CoppeliaSimEdu/programming/legacyRemoteApi/remoteApiBindings/lib/lib/Windows"
Los dos puntos indicarían el directorio donde se instalo Copelia.
Las referencias de estos bindings se encuentran en: [remote API reference](https://www.coppeliarobotics.com/helpFiles/en/remoteApiFunctionsPython.htm). Estas no abarcan todas las posibilidades que daría la API propia de Coppelia Sim (es bastante limitada). Si se deseara modificar elementos concretos se podría pedir lanzar una función que se hubiera definido en Coppelia Sim y que hiciera tareas mas complejas.
2. Lanzar el servidor de Coppelium. Hay dos formas:
	1. Por defecto al iniciarse la aplicacion de Coppelia Sim se lanzan un servidor según los parámetro indicados en:
		"../CoppeliaRobotics/CoppeliaSimEdu/remoteApiConnections"
	2. Si lo lanzas en tiempo de ejecución con:
			simRemoteApi.start 
		ver [ServerSide](https://www.coppeliarobotics.com/helpFiles/en/remoteApiServerSide.htm)
3. Lanzar tu código Python. Ver ejemplos en el mismo directorio donde se encuentran sim.py y simCost.py. Un código ejemplo mínimo seria
```python
import sim

# Conectarse al servidor
sim.simxFinish(-1) # just in case, close all opened connections
clientID = sim.simxStart('127.0.0.1',19997,True,True,5000,5)
if clientID!=-1:
    print ('Connected to remote API server')
    # Haces lo que desees
else:
    print ('Failed connecting to remote API server')
sim.simxFinish(clientID)
```
## Utilizar *simxCallScriptFunction*
Este método de sim sirve para ejecutar un funcion en Coppelia Sim. Para ello hace falta definirla previamente allí.
Para la descripción de los parámetros de la función se usaran los nombres que tienen en la definición del método dentro de *sim.py*. Estos nombres pueden variar en las referencias ( [remote API reference](https://www.coppeliarobotics.com/helpFiles/en/remoteApiFunctionsPython.htm)), aunque guardaran mismo orden. Adicionalmente sus descripciones son variadas acorde al caso de uso de este proyecto, junto con ejemplos. Los parámetros son:
1. *clientID*: como en el resto de funciones, el id del cliente que se obtiene al conectarse al servidor.
2. *scriptDescription*: Para nuestro caso pondremos el nombre del objeto que contenga el script hijo. Ej: "/prismatic_joint". Se recomienda poner nombre propio a los objetos.
3. *options*:  Indicaremos el tipo de sript. Para nuestro caso utilizaremos la constante: sim.sim_scripttype_childscript. Nuestros scripts serán en "hijos"  de algún otro objeto.
4. *functionName*: Es el nombre de la función. Ej.: "set_force"
5. *inputInts*: Es una lista de de los inputs tipo int. Si no se desea enviar ningun int, pasar una lista vacia. 
6. *inputFloats*: Análogo al anterior
7. *inputStrings*: Análogo al anterior
8. inputBuffer: Para otro tipo de inputs. Normalmente lo le pasaremos un buffer vacio con: *bytearray()*
9. *operationMode*: Parámetro necesario en casi todos los métodos. Normalmente usaremos la constante *sim.simx_opmode_blocking*. En este modo el cliente espera hasta recibir respuesta.
Un ejemplo:
```python
_,_,outputFloat,_,_=sim.simxCallScriptFunction(clientID,
                           "/prismatic_joint",
                            sim.sim_scripttype_childscript,
                            "give_force",
                            [],
                            [force],
                            [],
                            bytearray(),
                            sim.simx_opmode_blocking)
position = outputFloat[0]               
```
En este ejemplo se uso para modificar la fuerza del controlador de una junta, porque no existe un binding que permita hacer esa tarea especifica. Para ello se definí la función *give_force* en el scrip hijo de la propia junta. La junta se llama *prismatic_joint*.
En Coppelian Sim primero habría que añadir un scrip hijo al objeto de la junta. Para ello *seleccionar junta> click derecho > Add > Associeted child script > No threaded > Lua*. En ese script definimos la siguiente función:
```lua
function give_force(inputint, inputfloat, inputstr, buffer)
    force = inputfloat[0]
    objectHandle = sim.getObject(".")
    sim.setJointTargetForce(objectHandle, force)
    return {},{sim.getJointPosition(objectHandle)},{},""
end
```
Como se observa la función hay que definirla de manera que tenga cuatro inputs y cuatro outputs. Los tres primeras inputs y outputs serán arrays (en Lua se definen con "{}" y la indexacion empieza en 1, al igual que Matlab). El ultimo es el buffer. En Python los outputs serán un valor de referencia seguido de los cuatro outputs de la función en Coppelia Sim. El valor de referencia será 0 si no ha habido problema, otro valor si a surgido un error.
Si no se desean recibir nada no hace falta definirlo en la función de Coppelia Sim. En ese caso el valor de referencia será un 8 que indica que ha habido un problema en el server. Los inputs serán listas vacías y un *bytearray* de tamaño 0.