## Introducción
Este tutorial se enfoca mas en la parte Python y la explicación de su código. Para mas información ver: [[Comunicación Godot-Python]] y [[Godot Engine]]
## Pasos
1. Instalar godot-rl-agents:
	```shell
	pip install godot-rl
```
2.  Instalar Godot Engine:
	 https://godotengine.org/download/windows/
3.  Crear el entorno en Godot Engine (ver: [[Tutorial Godot]]). Ese entorno incluye:
	1.  Definir observaciones
	2.  Definir espacio de acciones
	3.  Definir recompensas
4. Crear controlador en Python. Los componentes clave del código son: 
	1. Importar  el  wrapper de *godot-rl* asociado al paquete de RL de Python que deseemos usar. En este caso usamos StableBaselines
	```python
from godot_rl.wrappers.stable_baselines_wrapper import StableBaselinesGodotEnv
from stable_baselines3 import PPO
	```
	2. Instanciar el entorno con el wraper.  La inicialización del wraper lanzara el servidor y pausara la ejecución del código hasta que se conecte el cliente de Godot. 
	```python 
env = StableBaselinesGodotEnv()
	```
	Se pueden usar variables adicionales como por ejemplo *env_path*. Esta variable es la ruta del binario del juego (el  .exe). En ese caso no haría falta ejecutar Godot, pero este método no abriría una ventana para ver la simulación. La ventaja de usar este metodo es aumentar el numero de entornos es paralelo con el parámetro *n_parralel*. Otra opción es lanzar el wraper sin *env_path* y después ejecutar el .exe (es equivalente a ejecutar la simulación desde Godot).
	3. Utilizar el entorno ya sea lanzando métodos tipo de gym o haciendo que un modelo aprenda.
	```python
# Inicializas el modelo, dando como parametro el entorno inicilizado en anteriomente
model  = PPO("MultiInputPolicy",env,  verbose = 2, n_steps=64)
model.learn(100000) # hacemos aprender al modelo

model.save("CartPoleModelGd")
del model
model  = PPO.load("CartPoleModelGd")

obs = env.reset()
for i in range(100):
        action, _state = model.predict(obs, deterministic=True)
        obs, reward, done, info = env.step(action)
```
	4. Por ultimo quedaría cerrar el entorno:
	```python
	env.close()
```
	Este método  manda a Godot acabar la simulación y cierra el server.
5. El ultimo paso es iniciar la simulación. Para ello ejecuta primero el script de Python. Después ejecuta el entorno en Godot.
	1. Para ejecutar el entorno en Godot en la **esquina superior derecha** del editor se encuentra los controles:
	![[Captura1.png]]