Toda la  información aquí expresada vienen inducida de los tutoriales y ejemplos que aportan los autores de esta herramienta, pero sobremodo de la lectura del código base. No existe una documentación de esta herramienta (únicamente una introducción con tutoriales de uso). Por esas razones esta serie de documentos puede presentar inexactitudes, ambigüedades o omisiones en la información.
Esto significa que para poder obtener un entendimiento mas completo del funcionamiento y usos de esta herramienta se requiere una exploración a fuerza bruta del código base conforme se exploran de forma practica distintos casos de uso.
[GitHub](https://github.com/edbeeching/godot_rl_agents)
## Introducción
Godot RL es una herramienta dirigida a la aplicación de RL con Python en el motor de videojuegos Godot Engine. La herramienta consiste de un paquete para Python y de un plugin para Godot Engine. Estos dos componentes aportan los medios para la comunicación entre  Python y Godot. 
El paquete de Python contiene wrapers para 4 librerias de RL de Python:
	1.  [StableBaselines3](https://stable-baselines3.readthedocs.io/en/master/)
	2. [Sample Factory](https://www.samplefactory.dev/)
	3. [Ray RLLib](https://docs.ray.io/en/latest/rllib-algorithms.html) 
	4. [CleanRL](https://github.com/vwxyzjn/cleanrl).
El uso de este paquete de Python es simple. Basta con declarar en un entorno utilizando el wraper que se desee. El wraper lanzara un servidor.  Godot se conecte al servidor y entonces Python  tiene el control del entorno diseñado en Godot.  
El plugin de Godot principalmente te agrega dos [[nodos]] nuevos: sync y AIControlerXX (donde XX pude se 2D o 3D). El nodo de *sync* es el controlador principal que conecta a la aplicación de Godot con el server de Python. También maneja los mensajes con Python y controla los agentes. El nodo de *AIControlerXX* sirve para definir parámetros como el espacio de observaciones y acciones. Este nodo servirá como enlace entre el entorno y *sync*
Para un tutorial de uso del paquete de Python ver [[Tutorial de uso de godot-rl-agents (Python)]] para aprender a utilizar la librería de Python.
Para saber de Godot Engine ver [[Godot Engine]]. Ver antes que su tutorial para tener un seguimento mas sencillo del mismo.
Para aprender a crear un entorno en Godot ver [[Tutorial Godot Engine]].
Para mayor comprensión del funcionamiento de esta herramienta ver [[Comunicación Godot-Python]] donde se muestra una descripción grafica de los explicado.
Para saber de Godot Engine ver [[Godot Engine]].
## Notas
En esta herramienta se han encontrado varias limitaciones:
1. Los wrapper  solo crea espacios de acciona de tipo diccionario con sub-espacios tipo Box (continuo) y Discrete. Aunque puedas definir espacios discretos de cualquier tamaño, internamente cuando debe pasar una accion, el wraper te devueve acciones binarias. Las acciones continúas se define entre -1 y 1.
2. Para el wrapper SB3, el entrono que crea es solo compatible con la política *MultiInputPolicy*.
3. Hay redundancia el los métodos que te permite para acelerar el entrenamiento. En el propio Godot Engine se puede instanciar el mismo entorno múltiples veces. A su vez al inicializar el wrapper se pueden lanzar varias instancias del programa de Godot. Por otro lado en Godot Engine puedes escalar la velocidad de la simulación. Es como gestionan estos métodos aun es un misterio. No se explican las diferencias útiles entre estos métodos.
4. Este plugin no diferencia entre el estado *terminate* y *truncate*, aunque en Python sus wrapper utilicen versiones de gymnasium que si lo hagan.
5. Como esta pensado para gestionar varios entornos, el método reset reseteara todos los entornos instanciaos en Godot. Si quieres que un entorno se resetee cuando termine la simulación, el encargado es el propio Godot. Normalmente cuando estas haciendo el entrenamiento de un entorno, el propio agente durante el entrenamiento manda una orden de reset cuando este alcanza el estado de *done*. 
6. Cuando se intento el polo empezara con una inclinación aleatoria cada vez que se reiniciaba el entorno, se encontró que la implementación no era directa. Comparando con MuJoCo en Godot las juntas no tienen un atributo que indiquen su posición de giro. Por tanto, como el *mesh* del polo tiene su ejes de coordenadas en el centro del polo, para poder girarlo desde extremo del polo hay que hacer matemática vectorial. (**Añadido a posteriori:** también se puede definir el *mesh* del polo, junto a su *collider*, de manera que su extremo empiece en el centro de coordenadas del *rigidbodiy* en el cual están anidados. Esto generara que al rotar el *rigidbody* el polo rotara respecto su extremo.. La forma en la que se esquivo este problema en el tutorial de Godot Engine fue aplicar una pequeña velocidad aleatoriamente al motor del joint, para que el polo emperezara a caer en una de las dos direcciones)
