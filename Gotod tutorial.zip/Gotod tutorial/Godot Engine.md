## Introducción
Godot Engine funcionan por un sistema de [[escenas]] y [[nodos]]. Estos son los bloques de construcción de Godot. Se definen  en una estructura de árbol. Un nodo define sus coordenadas y orientación en relación a las de su padre. De esta manera se pueden reposicionar bloques enteros de nodos de forma sencilla (si desplaza un nodo, todos sus hijos se desplazan con el). Este comportamiento también aplica en tiempo de simulación.
Tiene un lenguaje de programación propio parecido a Python. Algunas variaciones son: debes inicializar las variables escribiendo previamente al nombre de la variable, la palabra *var*. Las funciones se definen con *func* en lugar de *def*. Es un lenguaje de programación únicamente de objetos. Todo script debe heredar de otro hasta llegar a objeto base *Object* y lo que se define en el script son atributos y métodos adicionales  a los heredados.
Godot Engine tiene un sistema de renderizado y uno físico separados.
## Interfaz de Godot
Cuando abras Godot se te abrirá el explorador de proyectos de Godot. Este debería verse así:
![[Captura2.png]]
Cuando crees un nuevo proyecto basta con dar el directorio de un carpeta (idealmente vacía), donde se guarda todos los archivos del proyecto. El resto de opciones dejarlas en default. De la misma manera cuando importes un proyecto basta con dar el directorio de la carpeta o .zip que lo contenga.
Una vez creemos un proyecto nuevo veremos:
![[Captura3.png]]
El la **Zona 1** podremos ver los nodos y las instancias de escenas que componen la escena actual. Las instancias de escenas se mostraran como su nodo raíz. Se mostrara información como la presencia de un script asociados a un nodo. Cuando se crea una escena nueva, es esta zona se pedirá definir el nodo raíz como se muestra en la imagen. Se aconseja usar de nodo raíz un nodo en coherencia con el uso que se le vaya a dar a la escena.
En la **Zona 2** se mostraran los atributos asociados al nodo seleccionado en la **Zona 1**. Desde alli se pueden modificar. 
La **Zona 3** es un "explorador visual de escenas".  Los modos (parte superior centro de la zona) 2D y 3D sirven para visualizar y modificar dinámicamente algunos atributos de los nodos  (posición y orientación + otros atributos dependiendo del nodo). El modo Script te permite visualizar y modificar lo scripts que tengas abiertos independientemente de la escena que te encuentres. Viene con un explorador de metodos para moverte mas rápido por el script. El modo AssetLib sirve para instalar plugins como el que necesitaremos para el RL.
En la **Zona 4** el el explorador de recursos. En esa zona se mostraran archivos como por ejemplo: las escenas que se guarrden (.tscn), los scripts que creemos (.gd), imagines (.png ...) etc. Tambien se mostraran los archivos que importemos, o los archivos de los plugin que instalemos. 
En la **Zona 5** hay varias herramientas. Las que nos interesa son *Salida* y *Depurador*. *Salida* básicamente muestra los *print* internos o los que se hagan personalmente. *Depurador* sirve para monitorear la simulación en tiempo de ejecución. Un uso muy común es ver los errores que ocurren en tiempo de ejecución.
Estas son las elementos básico de la GUI de Godot que hacen falta para empezar. 
## Nodos básicos
Los nodos básicos que se utilizaran para nuestro caso de uso:
	1. **Rigidbody** (2D o 3D): Es el nodo sobre el que se aplican las Fisicas. Exige al menos un nodo hijo del tipo colisión ej: CollisionShape (2D o 3D). 
	2. **CollisionShape** (2D o 3D): Es el nodo necesario para que un cuerpo tenga "cuerpo fisico". Esto quiere decir que no pueda ser atravesado por otros nodos entre otras cosas. Además puede lanzar una señal cuando detecte un contacto.
	3. **MeshShape** (2D o 3D): Es una instancia visual. Necesaria para visualizar la forma del RigidBody. Tienes distintas formas básicas pero también puedes añadir con array de puntos definiendo vértices. También te permite cargar modelos diséñanos exteriormente. Además en la barra de herramienta del Modo 3D se puede crear rápidamente un gemelos para la colisión
	4. Nodos de tipo **joint**: En Godot hay 5 tipos de junta  3D y 3 para el 2d. La forma de funcionar es que enlazan dos objetos del tipo RigidBody3D con punto de unión la posición inicial del joint. Por tanto no es necesario anidarlos en ningún *RigidBody* , aunque es aconsejable, o al menos en la misma escena en la que se encuentren los cuerpos enlazados. La diferentes joints 3d son:
		1. **HingeJoint3D**: permite la rotación alrededor de un solo eje. Es decir da un grado de libertad angular entre los cuerpos respecto la posición inicial de la junta. 
		2. **SliderJoint3D**: permite el deslizamiento al lo largo de un eje. Es decir permite un grado de libertad lineal entre los cuerpos
		3. **PinJoint3D**: permite lar rotación libre entre los cuerpos respecto la posición inicial de la junta. Da los tres grados de libertad angulares.
		4. **ConeTwistJoint3D**: esta junta simula un junta de tipo ball-socket. Esta es una junta formada por la unido de una bola rodeada parcialmente de un capullo. Es como definir un *PinJoint3D* con limitaciones de rotación en dos ejes.
		5. **Generir6DOFJoint3d**: esta te da todos los atributos necesarios para definir tu junta a gusto. Esta es muy interesante por que tiene atributos de motor para todos las rotaciones o desplazamientos lineales. Te  permite crear cualquiera de las juntas anteriores.
		En lo referente a las juntas cuando se dice "posición inicial inicial de la junta" es por que la junta hereda de un Nodo3d (es decir tiene atributos para el posicionamiento espacial) y cuando se carga la simulación, se crea un junta "invisible" utilizando la posición y orientación iniciales del nodo junta. Uso el termino "invisible" por que la posición y orientación de esta junta se desentiendo del nodo de la junta una vez cargada. Posteriores alteraciones en tiempo de ejecución de la posición u orientación del nodo de la junta no alteraran la unión de los cuerpos.
		Para aquellas juntas que solo dan un grado de libertad, este se define con la orientación de la junta. En el modo de visualización 3D las juntas dan apoyo visual para saber la orientación de el grado de libertad. 
		Las juntas 2D tiene tienen algunos análogos a la 3D, concretamente al *PinJoint* y al *Slider*. Además tiene otro tipo que se comporta como muelle.  En 3D también se puede conseguir un comportamiento similar (al muelle)ncon la junta genérica.
		**Importante**: las juntas en Godot no son enlaces "fuertes". Los limites de movimientos que aplican se pueden romper.
	 6. **Camera** (2D o 3D): Imprescindible para visualizar en tiempo de ejecución
Existen nodos parecidos a los descritos pero especializados para algunos usos. Ejemplo: existe el nodo *PhysicalBone3D* el cual es un nodo para simular físicas de un esqueleto. 
También existen otra gran variedad de nodos útiles. Por ejemplo nodos de area, que sirven para detectar cuando un objeto entra en un área especifica. 
## Empezar a usar Godot
Seguir tutorial de ejemplo: [[Tutorial Godot Engine]]


