En este tutorial se recreara el experimento del Cart-Pole.
Pasos:
1. **Crea un proyecto nuevo en Godot**
2. En el explorador de la escena (parte derecha de la GUI) **crear un nuevo Nodo3D** (**basta con clickar en *Escena 3D***) . Este será nuestro nodo raiz de la escena principal. **Cambiarle el nombre a "Root"** (u otro nombre que lo identifique por lo que es). Para cambiarle el nombre hacer doble click sobre el nodo.
![[Captura4.png]]
3. Al nodo raíz añadir un nodo hijo que sea del tipo Nodo3D. Para ello **seleccionar el nodo raíz -> click derecho -> *Añadir Nodo Hijo***. Se abrirá un menú, **seleccionar Nodo3D y enter**. Este nodo nos servirá para encapsular nuestro entorno y desplazarlo libremente.. Cambiarle el nombre a *env*.
4. Ahora construiremos las partes del *env*: el carro y el polo. Para ello **crear dos nodos RigidBody3D en el nodo *env*** (*Añadir Nodo Hijo*). **Dentro de cada nodo rígido agregar un nodo MeshInstance3D**. Para encontrarlos rápidamente debería usar el buscador del explorador de nodos y escribir: "rigid" y "mesh" respectivamente. Los MeshInastance3D se define dentro de los cuerpos rígidos para que estos se desplacen con ellos (son un recurso puramente visual). Debería quedar como en la imagen:
![[Captura5.png]]
5.  Actualmente en el visualizador 3D no se observa nada. Eso es porque no hemos definido el  mesh que utilizaran los MeshInstance3D. Para ello seleccionar un MeshInstance3D e ir al inspector (parte izquierdo de la GUI). El primer atributo debería ser *mesh*. Seleccionar y elegir la opción *Nuevo BoxMesh*.  Habrá aparecido un cubo en el visualizador 3D. También en el inspector,  en el atributo *mesh*, se vera un visualización de la caja. Si se le hace click se expedirá un menú de atributos para el *mesh*. Allí se puede modificar el tamaño de la caja. Este será nuestro carro.
![[Captura6.png]]
7. Repetir el proceso para el palo/polo. Un *CapsuleMesh* debería servir. Cambiar los nombres de los cuerpos rígidos para hace un mejor seguimiento de las partes (Ej: llamalos "cart" y  "pole" respectivamente). En el visualización 3D se deberían ver el carro y el polo atravesados. Ajuste los tamaños y desplace el polo a la parte superior de la caja. Para ello seleccione su cuerpo rígido y desplácelo en el visualizador 3D usando los ejes. Para ajustar la posición se puede utilizar los atributos de posición que se encuentran en el menú despegable *Trasform* del Nodo3D del que hereda el cuerpo rígido. Estos atributos se modifican desde el inspector del cuerpo rígido. Para replicar el experimento ver las dimensiones, posición y otros atributos en el anexo del final del documento.
![[Captura7.png]]
Para darle colores hay que añadir un nuevo material genérico en el MeshInstance3D. Para ello, en el inspector  del MeshInstance3D, agregar en el atributo del materia un nuevo *StandarMaterial3D* como se muestra  la imagen. Igual que con el mesh aparecera una previsualizacion del material. Si se selecciona la previsualización se expandira su menu. En el menú despegable de nombre *Albedo*, se encuentra el atributo del color para modificar.
![[Captura9.png]]
8. Falta los colíder los cuales hay que definir como hijos de los cuerpos rígidos, como expresa su señal de advertencia. Para crear colíder que se ajusten a nuestras mallas hay dos formas:
	1. Si utilizamos figuras geométricas simples (caja, esfera, capsula o cilindro) se aconseja hacer una instancia de CollisionShape3D y en su atributo *shape* elegir una formar equivalente a la de la malla, y darle la misma dimensiones.
	2. Si nuestra malla es mas compleja utilizar la herramienta de colíder hermano. Para ello seleccionar el nodo del MeshInstace3D. Aparcera en el visualizador 3D una nueva herramienta llamada *Malla*. Selecciónala y elige la opción *Crear Colider Convexo Hermano*.
	![[Captura8.png]]
9. El siguiente paso es juntar los dos cuerpos por una junta. Crea el nodo HingeJoint3D (escribir en el buscador "joint") como hijo del *cart* (definirlo en el *cart* con el único propósito de mantener un orden). A la junta hay que pasarles los cuerpos rígidos. Para ello selecciona la junta y en el inspector selecciona el atributo *Node A*. Se abrirá una pestaña con el arbol de nodos. Seleccione el nodo *cart*. Repita para el atributo *Node B* y el cuerpo físico *pole*.
La junta dan información visual de su funcionamiento.  En el modo 3D podemos ver que, para la junta de tipo bisagra, su capacidad de rotación se expresa con una circunferencia. Esta nos indica la dirección del giro. Por defecto gira alrededor del eje z (azul). Para modificarlo rota la junta. 
En la imagen esta la junta seleccionada. Los dos semicírculos muestran los arcos en los que pueden girar los *rigidbody* (El giro esta limitado entre -90 y 90). Se han ocultado los *mesh* para que no taparan los ángulos de giro
![[Captura10.png]]
10. Desplazar la junta al punto de unión. Para una buena simulación desplaza la junta al centro de la semiesfera del extremo de la capsula (extremo inferior). Activa limites de la junta en sus atributos (por defecto estarán entre -90 y 90 grados). Otro atributo interesante de la junta es *Exclude Nodes From Colison* que por defecto esta activado. Si se desactiva, hay que asegurarse que los cuerpos no están atravesados entre si (podría llevar a interacciones extrañas). Para este entorno bastara con el limite de rotación.
11. Hace falta bloquear al *cart* el movimiento en el eje y. Para ello active el checkbox de la propiedad *Linear Y* del despegable *Axis Lock* en el inspector del nodo *cart*. También bloque el *Angular Z* para que la inercia del polo no hago rotar al carro. 
12. Como norma general desactive siempre el chekbox *Can Sleep* en el inspector de todos los *RigidBody*. Esto impide que la físicas del RigidBody no se ejecuten cuando no se a superado un umbral de velocidad.
13. Añadimos un script al nodo *cart* para poder tener control sobre el. Haga click derecho sobre el nodo *cart* seleccione *Añadir Script*. Mantenga el nombre sugerido y créelo. Se abrirá el script que hereda de RigidBody3D. Esto implica que podemos utilizar todos los métodos y atributos del nodo RigidBody3D al que hemos asociado este script, además de añadir nuevos. También aparecerán dos métodos vacíos. El primer método (*_ready*) se llamara cuando se inicialice el nodo. El  segundo (*_process*) es un metodo que se llama en cada frame. Para este tipo de aplicaciones de simulación es mejor utilizar el método *_physics_process* para no depender del framerate.
14. Sustituye ese código por:
```godot
extends RigidBody3D

@export var force:float = 10

var vecforce: Vector3

func _physics_process(delta):
	_my_set_force()
	
func _my_set_force():
	if Input.is_action_just_pressed("ui_left"):
		vecforce = Vector3(-1,0,0)*force
		set_linear_velocity(Vector3())
		set_constant_force(vecforce)
	elif Input.is_action_just_pressed("ui_right"):
		vecforce = Vector3(1,0,0)*force
		set_linear_velocity(Vector3())
		set_constant_force(vecforce)
```
Este código permite un control simple del usuario en tiempo de ejecución utilizando las flechas del teclado (derecha e izquierda) o las teclas "A" y "D". La variable "@export var force:float = 1"  convierte a la variable *force* en un atributo modificable desde el inspector.
15. Antes de ejecutar  la simulación hace falta una cámara para visualizarla. Añade como hijo del nodo raíz un nodo Camera3D. Aparecera en coordenadas 0 0 0. Moverla hacia atrás (positivo eje z, el azul) y un poco para arriba (positivo del eje y, el verde). Cuando tenga seleccionada la cámara aparcera en el visualizador 3D un chekbox para ver una la vista previa de la cámara.
16.  Ejecute Godot para testear el entorno. Seguramente con este entorno es practicamente imposible para un humano mantener el equilibrio del polo. Para facilitar la tarea reduce el atributo *Gravity Scale* en el inspector del *pole*. Con un valor de 0.1 debería facilitar bástate mantener el equilibrio.
17. El siguiente paso es instalar y activar el plugin para los rl agents:
	1. Ir a modo *AssetLib* y escribir en el buscador "RL"
	2. Seleccionar, descargar e instalar el plugin *Godot RL Agents*. Cuando selecciones el plugin deseado se abrirá una ventana con una descripción del plugin y la opción de descargar. Descárgalo. Cuando se descargue se abrirá una ventana indicando el lugar de instalacion y los recursos con los que entra en conflicto. Clickar *Instalar*.
	3. Activar el plugin. Para ello en *AssetLib* clicar el botón plugin (esquina superior derecha). Se abrirá una ventana con los plugins instalados. Marcha la checkbox de estado del plugin.
18. Añadiremos el nodo del AIController3D como hijo de *cart*. Despues haremos clik derecho sobre el y seleccionaremos *Extender Script*. Borrar la funciones predeterminadas y sustituirlo por:
```godot
extends AIController3D

var move_action : float = 0.0

func get_obs() -> Dictionary:
	var pole_orentation = to_local(_player.pole.global_rotation).z
	var pole_angVelocity = to_local(_player.pole.angular_velocity).z
	
	var obs = [pole_orentation, pole_angVelocity]
	return {"obs" : obs}

func get_reward() -> float:	
	return reward
	
func get_action_space() -> Dictionary:
	
	return {
		"move_action" : {
			"size": 1,
			"action_type": "continuous"
		},
		}
	
func set_action(action) -> void:	
		move_action = action["move_action"][0]


```
Notas sobre el código: 
	Estos cuatro metodos tiene que ser rellenados en todos lo entornos que hagamos.
	La variable *_player* contiene al nodo del script que controlara al agente. En nuestro caso utilizaremos *cart*. En *cart* guardaremos el nodo pole en una variable del mismo nombre. Por esa razón con *_player* podemos acceder a *pole* como si fuera un atributo.
19. En cart pondremos el siguiente código:
```godot
extends RigidBody3D


@export var force :float= 10
@onready var pole := get_node("../Pole")
@onready var ai_controller = $AIController3D
var vecforce : Vector3
var POLE_POS :Vector3
var CART_POS: Vector3

#var HingeJoint3D :Vector3



# Called when the node enters the scene tree for the first time.
func _ready():
	ai_controller.init(self)
	POLE_POS = pole.global_position
	CART_POS = global_position
	vecforce = Vector3()
	
func game_over():
	ai_controller.done = true
	ai_controller.reward -= 200
	ai_controller.needs_reset = true
	
func _physics_process(delta):
	if ai_controller.needs_reset:
		ai_controller.reset()
		reset()
		return
		
	var dirforce : int
	
	if ai_controller.heuristic == "human":
		my_get_force()
		set_constant_force(vecforce)
	else:
		if pole.global_rotation.z < 0:
			ai_controller.reward += 1/(-pole.global_rotation.z+0.001)
		else:
			ai_controller.reward += 1/(pole.global_rotation.z+0.001)
		dirforce = ai_controller.move_action
		set_constant_force(Vector3(1,0,0)*force*dirforce)

func my_get_force():
	if Input.is_action_just_pressed("ui_left"):
		vecforce = Vector3(-1,0,0)*force
		set_linear_velocity(Vector3())
	elif Input.is_action_just_pressed("ui_right"):
		vecforce = Vector3(1,0,0)*force
	if Input.is_physical_key_pressed(KEY_Q):
		print(constant_force.x)
	
func reset():
	var aux = pole.rng.randf_range(-1,1)
	vecforce = Vector3()
	set_constant_force(Vector3())
	set_constant_torque(Vector3())
	set_linear_velocity(Vector3())
	set_angular_velocity(Vector3())
	set_global_position(CART_POS)
	set_global_rotation(Vector3())
	pole.set_constant_force(Vector3())
	pole.set_constant_torque(Vector3())
	pole.set_angular_velocity(Vector3(0,0,1)*aux*0.01)
	pole.set_linear_velocity(Vector3())
	pole.set_global_rotation(Vector3())
	pole.set_global_position(POLE_POS)
```
Notas del código: 
Al principio del código se inicializan punteros al nodo *polo* y al AiControler para poder acceder a sus atributos (*get_node()* y *$* son equivalentes). Este será el script desde el que controlaremos el entorno. 
Elementos necesarios:
	ai_controller.init(self): se llama en el método *_ready()*. Así le pasamos este nodo al nodo de AIController. A su vez nos permite de esta manera definir las observaciones como hemos visto en el codigo del AIController.
	Algún método de reset, que devuelva al estado original al entorno.
	Preguntar si el entorno necesita resetearse, y en caso afrimativo llamar al metodo *reset* de *AIControler3D* y al propio del script que hemos creado.
	Por ultimo se modifican la recompensa y se aplica la fuerza correspondiente a la accion.
	
20. Instanciar el nodo sync en la raiz. El nodo sync es un nodo del plugin. Contiene el script maestro que gestiona la conversación con Python. Tiene dos variables modificalbes en el inspector:
	1. *Speed Up*: sirve para  escalar la velocidad de la simulación.
	2. *Action Repeat*: Indica el numero de ticks fisicosque espera antes de ejecutar alguna acción. Es una forma de modificar el steprate del agente. El steprate se defenira por la combinación de esta variable y de los tick físicos por segundo (por defeto son 60).
21.  *sync* puede gestionar múltiples instancias del entorno simultáneamente. La forma de gestionarlas es accediendo a los IACntrolesr pertenecientes al grupo "Agent".  Seleccione cualquier nodo. En la zona del inspector seleccione *Nodos* > *Grupos* >*Administrar Grupos*. Se abrirá una ventana con tres celdas vacías. En la primera, abajo, escribe *Agent* y haz click en *Añadir*. En la segunda segunda celda busa el AIController3D y añádelo al grupo.
22. Convirtamos nuestro entorno en escena. Haga click derecho sobre el nodo raíz de nuestra escena (*env*). Seleccione la opción *Guardar Rama como Escena* y guárdelo. Toda la rama se habrá colapsado en solo el nodo raiz, que a partir de ahora sera una escena. Ahora puede instanciar los que desee. Para modificar la escena habrala en el editor. Para ello haga click en el nuevo icono que ha aparecido el nodo de nuestro entorno. O haga doble click en el archivo que ha creado al guardarlo como escena (env.tscn).
Ya ha acabado. Pruebe a lanzar	su archivo de python y ejecutar la simulación.