Matlab posee un toolbox de aprendizaje reforzado llamada: [Reinforcement Learning Toolbox](https://es.mathworks.com/products/reinforcement-learning.html). Entre las distintas herramientas que aporta estan:
1. Una librería de Simulink
2. Funciones especializadas para definir los entornos.
3. Una app para gestionar los entornos, agentes y sus entrenamientos.
4. Capacidad de hacer redes neuronales custumizables, para agentes custom (Hay una app de Deep Learning, de Matlab, que permite diseñar redes neuronales de forma grafica).
Limitaciones: 
1. No hay una implementación directa de sensoria avanzada como lidar o fotografica. Unicamente se tiene la sensoria de las juntas (velocidades, posiciones, aceleraciones) + sensoria de calculo propio, por ejemplo, juntar la masa y la aceleración  para calcular un fuerza. También tiene bloques para sensar las trasformadas entre frames o la inercia de un cuerpo o conjunto de cuerpos(masa, centro de masa, matriz de inercia...)
	Esta limitación se entiende por que Simulink no es una aplicacion orientada entornos 3D, sino a modelar sistemas en general.
Requerimientos:
1. [Deep Lerning Toolbox](https://es.mathworks.com/products/deep-learning.html)
2. Si se desea hacer entornos en 3D se recomienda [Simscape Multibody](https://es.mathworks.com/products/simscape-multibody.html).
## Simulink
Simulink en un entorno de diseño de sistemas o modelos físicos. Tiene gran potencial porque permite combinar las distintas librerías permitiendo modelos con cierto nivel de complejidad. Por ejemplo Simscape Multibody, aparte de tener bloques para diseñar entornos 3D articulados, también pose sub-librerías para simular sistemas hidráulicos, eléctricos o gaseosos entre otros, que puedan interaccionar con el modelo 3D. 
Un ejemplo es el pistón de la imagen. Por un lado se simula un sistema fisico que compondría las dos cámaras que se forma en el pistón junto con un sistema de control. Al el conjunto traduce la señales del controlador en una fuerza que se pasa a la junta del modelo 3D.
![[Matlab/Imagenes/Captura1.png]]
## Setup
Para empezar a usar esta librería hay que:
1. Tener instalado Matlab con simulink. Estos requieren licencia. Diversas universidades tiene licencia para sus estudiantes e investigadores, como es el caso de la UNAV:
	1. [Matlab](https://es.mathworks.com/products/matlab.html)
2.  Desde Matlab instalar los *Add-on* . 
	1. Para ello con matlab iniciado en la pestaña *Home* seleccionar el icono *Add-on*. ![[Matlab/Imagenes/Captura2.png]]
	2. Se abrirá una pestaña nueva. En ella buscar e intalar los siguientes *Add-on*:
		1. *Deep Learning Toolbox*
		2. *Reinforcement Learning Toolbox*
		3. *Simscape Multibody*
## Workflow
El flujo de trabajo al diseñar un experimento de RL con esta herramienta será casi siempre el mismo, siempre que se quieran simular entornos en 3D. Si se desea otro tipos de entornos, la *toolbox* de RL posee diversas funciones para diseñar entornos 2D o mas abstractos, como por ejemplo funcione especializadas en crear *grid-worlds* (ver documentación de los [entornos](https://es.mathworks.com/help/reinforcement-learning/environments.html)).
Los pasos a seguir serán:
1. Diseñar en Simulink un entorno 3D. Para ello utilizar la libreria *Simscape Multibody*. Ver [[Simscape Multibody]] para aprender lo básico sobre esta librería y aprender a diseñar un entorno para RL en simulink.
2. En Matlab crear un script que servirá para crear en el *workspace* un variable que hace referencia a nuestro entorno de Simulink. Ver [[Setup del entorno]]. Este variable entorno de Matlab contiene información sobre las observaciones y acciones definidas en Simulink. Si en el modelo de Simulink se modifica algún apartado que afecta a los tipo de observación u acción, abra que modificar el script para que encaje con Simulink y crear un variable del entorno actualizado.
3.  Lanzar la aplicación de Matlab: *Reinforcement Learning Designer*. Para ello escribir en la ventana de comandos de matlab: *reinforcementLearningDesigner*. Ver [[Reinforcement Learning Designer]]  En esta aplicación:
	1. Importaremos nuestro entorno desde el *workspace*.
	2. Crearemos un agente a partir del entorno y eligiendo la política.
	3. Entrenaremos el agente.
	4. Exportaremos el agente al *workspace* para probarlo en Simulink.
	Una modificación en la variable que contenga el entorno supondrá importarlo de nuevo.
	