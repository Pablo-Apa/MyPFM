Después de diseñar un entorno en simulink hace falta crear un variable que haga referencia a ese entorno, para poder importarlo a la aplicación de *Reinforcement Learning Designer*.
El siguiente código muestra es un ejemplo para el tutorial de CartPole visto en [[Simscape Mustibody]]. 
```matlab
% Defino el espacio de observaciones
busobject = Simulink.Bus()
busobject.Elements(1) = Simulink.BusElement;
busobject.Elements(1).Name = "cart_pos";
busobject.Elements(2) = Simulink.BusElement;
busobject.Elements(2).Name = "cart_vel";
busobject.Elements(3) = Simulink.BusElement;
busobject.Elements(3).Name = "pole_ang_pos";
busobject.Elements(4) = Simulink.BusElement;
busobject.Elements(4).Name = "pole_ang_vel";

obsInfo = bus2RLSpec("busobject","Model","CartPole");

% Defino el espacio de acciones
actInfo = rlNumericSpec([1 1]);
actInfo.LowerLimit = -1;
actInfo.UpperLimit = 1;
actInfo.Name = "ang_vel";

% Defino al bloque del agente y el modelo de simulink
agentBlk = "CartPole/RL Agent";
mdl = "CartPole";

% Creo el entorno con la variables definidas antes
MyCartPoleEnv = rlSimulinkEnv(mdl,agentBlk,obsInfo,actInfo)
MyCartPoleEnv.ResetFcn = @(in)mylocalreset(in);
MyCartPoleEnv.UseFastRestart = "off";
```
En las observaciones, por simplicidad, en simulink se hizo un bus de señales. Por ello en el script se define un objeto tipo bus y se utiliza la función especia *bus2RLSpec*. Otra posibilidad hubiera sido usar la misma función que con las acciones, *rlNumericSpec*. En ese caso en simulick habría que haber juntado las observaciones en un vector. Para definir espacios discretos existe la funcion *rlFiniteSetSpec*. La información se guarda variables parecidas a estructuras. Esto permite combinar observaciones discretas y continuas aumentado el tamaño de las estructuras de forma dinámica.
Después hay que definir las rutas al modelo de simulink y al bloque de *RL Agent* contenido en el mismo. Idealmente guardar todo en el mismo directorio.
Por ultimo damos al entorno una función propia de reseteo que hemos definido aparte y se encuentra en el mismo directorio del trabajo.
La función de reseteo que hemos definido hace variaciones en parámetros de bloques del modelo de simulink. Por eso hace falta cambiar parámetro *UseFastRestart* a "off" (se hace en el código de arriba) para que nuestra función pueda hacer cambios. Esta función hace que el polo empiece con un ángulo aleatorio en un rango de 10 grados alrededor de la posición de origen. Su código se muestra a continuación.
```matlab
function in = mylocalreset(in)
ang = round(rand*10 -5);
anglesstr = num2str(ang);
in = setBlockParameter(in,'CartPole/Enviroment/Revolute Joint',"PositionTargetValue", ...
anglesstr);
end
```
Los parámetros de los bloques de simulink son del tipo string. Por ello hacemos la trasformacion. El parametro *in* hace referencia al modelos de simulink actual que se esta usando. *setBlockParameter* es una funcion que utilizaremos mucho para modificar parámetros. Su segundo input el la ruta, dentro del modelo de simulink, al bloque que deseamos modificar. El tercer input el parámetro que queremos escribir (Matlab sugiere posibles valores). El ultimo input es el valor en que queremos definir.
En este ejemplo concreto se esta definiendo el estado inicial de la junta que une el polo y el *cart*. 
Los nombres de los parametros de los no se pueden deducir directamente de las ventanas de los bloques. Con la función *get_param* puedes acceder a esos nombres. Con el siguiente ejemplo se obtiene una lista de todos los nombres de los parámetros del bloque de la junta que une el *cart* y el polo.
```matlab
get_param('CartPole/Enviroment/Revolute Joint','DialogParameters')
```