## Introducción
En apartado  se presenta un ejemplo de entorno basado en gym que simula con MuJoCo.
```python
class MyCPenv(gym.Env):
    metadata = {"render_modes": ["human"]}

    def __init__(self, xmlPath, render_mode = None):
        self.observation_space = spaces.Box(low = np.array([-75, -10000, -10000, -1]),
                                            high = np.array([75, 10000, 10000, 1]))
        self.action_space = spaces.Discrete(5)
        self._action_to_force = {
            0: -10,
            1: -5,
            2: 0,
            3: 5,
            4: 10
        }

        self.model = mujoco.MjModel.from_xml_path(xmlPath)
        self.data = mujoco.MjData(self.model)

        self._timeStep = .01 #sec
        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode = render_model

    def _render_frame(self):
        renderer = mujoco.Renderer(self.model, 480,480)
        renderer.update_scene(self.data, camera = "maincamera")
        frame = cv2.cvtColor(renderer.render(),cv2.COLOR_BGR2RGB)
        cv2.imshow('frame',frame)
        cv2.waitKey(math.ceil(1000*self._timeStep))

  

    def _get_obv(self):
        obv = np.array([self.data.joint('pole').qpos[0],        #angulo del polo
                        self.data.joint('mainjoint').qvel[0],   #velocidad del cubo
                        self.data.joint('pole').qvel[0],        #velocidad de rotacion de polo
                        self.data.joint('mainjoint').qpos[0]])  #posicion del cubo

        return obv

    def _get_rew(self, obs):
        if np.absolute(obs[0]) < .1746:
            return np.absolute(obs[0])
        else:
            return -np.absolute(obs[0])*10

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        
        mujoco.mj_resetDataKeyframe(self.model, self.data, 0)
        self.data.joint('pole').qpos = (self.np_random.random() - .5)*0.1746
        observation = self._get_obv()  

        if self.render_mode == "human":
            self._render_frame()
        return observation, None

    def step(self, action):
        force = self._action_to_force[int(action)]*100
        redFramerate = 1/self._timeStep
        stepTimeLim = self.data.time + self._timeStep
        self.data.ctrl = force

        while self.data.time < stepTimeLim:
            mujoco.mj_step(self.model, self.data)
        observation = self._get_obv()
        truncate = True if np.absolute(observation[0]) > 1.309 else False
        info = {}
        reward = self._get_rew(observation)

        if self.render_mode == "human":
            self._render_frame()

        return observation, reward, False, truncate, info

    def reder(self):
        self._render_frame(self)
```
En este ejemplo se muestran muchos de las opciones de uso que nos permite la librería de mujoco.
Lo primero es definir la clase heredándola de el entrono base de gym (gym.Env).
En el **__init__** se define el espacio de observaciones y el de acciones según los estándares de gym. Además se define una diccionario para traducir las acciones en fuerzas que se utilizaran en el actuador. Se crean la estructura del modelos y la de datos. Tambien se ha definido la variable *_timestep* que indica el tiempo que dura el paso del **agente** (que no los de la simulación). Es decir es el tiempo que pasa entre que el agente cambie de acción. 
Se han creado funciones auxiliares para obtener las recompensas y las observaciones.
Cada vez que se llama step, primero se cambia la fuerza que aplica el actuador y después se ejecutan en MuJoCo múltiples pasos hasta alcanzar el tiempo de *_timestep*. Por ultimo se adquieren las observaciones y recompensa. Por la naturaleza de este entorno, no se puede alcanzar el estado de terminación, por ello siempre se devuelve *False*.
Solo tiene un modo renderización que es *human*. Básicamente renderiza conforme se hacen las acciones es decir con un framerate igual al inverso de *_timestep*. Si no se especifica el modo de renderizado *human* en entorno no renderizará nada.