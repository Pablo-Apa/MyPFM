## Introducción
Los modelos de MuJoCo siguen una lógica de ramificaciones de árbol. El lenguaje para definirlos esta basado en XML.
## Elementos básicos de XML
Para un documentación completa de todas las referencias XML que permite MuJoCo ver: [XML Reference](https://mujoco.readthedocs.io/en/stable/XMLreference.html). 
Los elementos mas básicos son:
1. ***worldbody***: Es cuerpo principal donde se definen el resto de elementos fisicos que componen el mundo. No puede tener de hijos a *inertial* o *joints*. Supone el origen de coordenadas.
2. ***body***: el el elemento principal por el que se construyen los arboles kineticos vía anidamiento. Sus atributos principales son *name* y *pos* (posición). 
3. ***geom***: Sirve para definir las formas geométricas. Normalmente se definen dentro de *body* o *worldbody*. Sus atributos mas importantes son:
	1. *type*: el tipo de forma. Tiene varias formas default como *cylinder*, *plane*, *box*, *sphere*, *capsule*... Ademas puedes cargar mallas propias de archivos exteriores o definiendo uno propio con los vertices. Para estos dos casos se requiere definir un *asset* del tipo *mesh*. Ejemplo de *asset* contiene el ejemplo de mas abajo
	2. *size*: Define el tamaño. El tipo de variable son un vector de 3 reales máximo. Varia dependiendo del tipo de geom. 
	3. *fromto* (real (6)): Es otra forma de definir un el tamaño de una figura. Solo sirve si el tipo es: *box*, *cilinder*, *capsule* o *ellipsoid*. Las tres primeros elementos definen el inicio, los tres siguientes el final. El grosor lo define el primer elemento de *size*.
	4. *density*: Define la densidad del cuerpo. Por defecto el la del agua (1000)
Además también tiene los atributos de *name* y *pos*. La posición es relativa al cuerpo en el que este anidado.
4. ***joint***: Cuando es definida anidada en un *body*, enlaza este con el *worldbody/body* padre. Atributos básicos:
	1.  *type*: El tipo de junta. Puede ser: *free*, *ball*, *slide*  o *hinge*. La *free*  hace al cuerpo flotante. La *ball* da los tres grados de libertar rotacionales. La slide da un grado de libertar traslacional. La *hinge* da un grado de libertad rotacional.
	2. *axis*: Vector de 3 dimensiones que indica el eje de libertad para la junta de tipo *hinge* y *slide*.
	3. *limeted* ('true','false', 'auto')Indica si la cunta tiene limites o no.
	4. *range* (real (2)): los limites de la junta.
	Adicionalmente tiene atributos de nombre y posición.
5. **site**: Sirve para definir elementos en el espacio que no tienen interacciones físicas. Se pueden utilizar para definir puntos donde enlazar tendones, o definir motores y que funcionen como propulsores. También puedes definir figuras, para dar un apoyo visual al mundo. Los atributos esenciales son el de posición, el del nombre y el del tipo (equivalente al  de *type* del *geom*).
6. ***default***: fuera del *worldbody* sirve para definir valores de otros elementos distintos a defalult. Ejemplo: puedes definir que los *geom* por defecto sean cajas de color rojo.
```xml
<mujoco>
	<default>
		<geom type = 'box' rgba = '1 0 0'/>
	</default>

	<worldbody>
		...
	</worldbody>
</mujoco>
```
7. ***actuator***: sirven para definir 'controladores' a partir de definir distintos parámetros. Se pueden definir en *joint*, *body*, *site*, *tendon*. Para ello en el atributo de mismo nombre dar el valor de *name* del elemento en el que se desea definir el actuador. En los actuadores hay atajos para definir distintos tipos (de motor, de velocidad, de posicon, de adhesion). Para entender como se computan las fuerzas en un actuador ver el apartado [Actuation model](https://mujoco.readthedocs.io/en/stable/computation/index.html#actuation-model). Para entender todos los parámetros y opciones que aporta un actuador ver [Actuator ](https://mujoco.readthedocs.io/en/stable/XMLreference.html#actuator). De forma resumida el los actuadores tiene una fuerza de entrada que se define en *data.ctrl*. Si hay varios actuadores el atributo será un array, por eso es recomendable darle nombre a los actuadores para tener un acceso mas sencillo. A esa fuerza se le aplicaran una serie de operaciones para sacar una salida. Entre esas operaciones están una escalada (*gainprm* real(los necesarios)), una suma del *bias* (biasprm) y una escalada "vectorial" (*gear*). El ultimo define los eje en el que se hace la fuerza (3 primeros elementos) y el eje en el que se hace el par (3 ultimos). El numero de parametros utilizados en la ganancia o el bias depende del tipo de ganancia y bias definido el los atributos (*gaintype* y *biastype*). Al principio es recomendable usar los shorcuts, que ya tienen predefinidos todos estos elementos para distinta funcionalidades.
8. ***camera***: Elemento clave para elegir el tipo de visualización. Se define dentro del *worldbody*. Su atributo de nombre es especialmente importante para poder renderizar desde la visión de la cámara. Otros atributos importantes son *pos* y  *euler* para definir su posicion y orientacion. 
Además existe otra multitud de herramientas como sensoria, recursos (assets), opciones del entorno diversas. 
## Ejemplo cart-pole xml
Este es un ejemplo para modelar el experimento cart-polo. La forma de mover el carro es definiendo un propulsor en el centro del carro. Para ello se define un actuador del tipo motor al que se le asocia un elemento del  tipo *site*. 
```xml
<mujoco>

    <asset>
        <texture name="grid" type="2d" builtin="checker" rgb1=".1 .2 .3" rgb2=".2 .3 .4" width="300" height="300"/>
        <material name="grid" texture="grid" texrepeat="8 8" reflectance=".2"/>
    </asset>

    <worldbody>
        <geom type = "plane" size = "10 10 1" pos = "0 0 -1.5" material = "grid"/>
        <camera name="maincamera" pos="0 -3 0.5" euler="85 0 0 "/>
        <light cutoff="100" diffuse="1 1 1" dir="-0 0 -1.3" directional="true" exponent="1" pos="0 0 1.3" specular=".1 .1 .1"/>
        <body name = "cartpole" pos = "0 0 0">
            <joint name = "mainjoint" type = "slide" axis = "1 0 0" limited = "true" range = "-1 1"/>
            <geom type = "box" pos = "0 0 0" size = "0.2 0.2 0.2" rgba = "1 0 0 1" density ="1000" />
            <site name = "sliderPropulsor"/>
            <body>
                <joint type = "hinge" pos = "0 0 .2" axis = "0 1 0" limited = "true" range = "-75 75" name = "pole"/>
                <geom type = "capsule" fromto = "0 0 0.2 0 0 1" size = "0.05" rgba = "1 0 0 1" density = "1000"/>
            </body>
        </body>
    </worldbody>
    
    <actuator>
        <motor name = "sliderMotor" site = "sliderPropulsor"/>
    </actuator>
    
</mujoco>
```
Este ejemplo tiene elementos extra no vistos en el apartado anterior como por ejemplo los *assets*. Estos aportan textura al plano horizontal para así tener una ayuda visual. Además en el worldbody hay definidos una luz para tener mejor visualización.
