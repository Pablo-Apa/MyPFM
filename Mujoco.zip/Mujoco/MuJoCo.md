## Introducción
MuJoCo es un motor físico que tiene bindings para Python. Estos permite utilizar y controlar MujJoCo desde Python.
Entre las funcionalidades que no otorga están:
1. Acceso de lectura y escritura sobre toda los datos del modelo (velocidades, aceleraciones, posiciones, controladores/actuadres...) 
2. Controlar los pasos de la simulación
3. Renderizado de frames
4. Incluye un visualizador. Este visualizador contiene paneles para controlar diferentes opciones del entorno.
Al tener MuJoCo integrado en Python  se puede crear un entorno basado en gymnasium que utilice a MuJoCo. Una vez creado el entorno basado en gymnasium se puede utilizar cualquiera de la múltiples herramientas de RL que ofrece Python.
MuJoCo tiene extensa documentación:
1. [GitHub](https://github.com/google-deepmind/mujoco)
2. [Documentacion](https://mujoco.readthedocs.io/en/stable/overview.html)

## Funciones básicas
Los bindings de Python no tiene documentacion propia. La razón es que todas las funciones, variables, métodos y atributos comparten el mismo nombre que en C++.  Para ver la documentación de la API de MuJoCo ver [API Reference](https://mujoco.readthedocs.io/en/latest/APIreference/index.html). Los bindings de MuJoCo, para ser mas parecidos a lo que se esperaría de una librería de Python, divergen en algunos aspectos de la API de MuJoCo (ver [Python Bindings](https://mujoco.readthedocs.io/en/latest/python.html)).
Aquí exploraremos las distintas funcionalidades básicas que ofrece MuJoCo. Para un tutorial/ejemplo mas completo ver: [Tutorial](https://colab.research.google.com/github/google-deepmind/mujoco/blob/main/python/tutorial.ipynb)
1. Lo primero instalar MuJoCo:
```shell
pip install mujoco
```
2. Importar mujoco:
```python
import mujoco
```
3. Cargar el modelo. Se puede definir en un archivo exterior (.xml) y cargarlo o definirlo en el propio script de Python:

```python
xml = """

<mujoco>

  <worldbody>

    <geom name="red_box" type="box" size=".2 .2 .2" rgba="1 0 0 1"/>

    <geom name="green_sphere" pos=".2 .2 .2" size=".1" rgba="0 1 0 1"/>

  </worldbody>

</mujoco>

"""

model = mujoco.MjModel.from_xml_string(xml)
data  = mujoco.MjData(model)
```
ó
```python
model = mujoco.MjModel.from_xml_path(xmlPath)
data = mujoco.MjData(self.model)
```
La variable *modelo* contiene la descripción del modelo, es decir, todos los valores que no cambien con el tiempo: numero de *geoms*, sus colores etc.
La variable data contiene la información dinámica del modelo: posiciones, velocidades, contactos ect.
2. Acceder a información del modelo:
```python
# Forma 1
model.geom_rgba
# Forma 2
id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, 'green_sphere')
model.geom_rgba[id, :]
# Forma 3
model.geom('green_sphere')
# Forma 4
model.geom('green_sphere').rgba
# Forma 5
[model.geom(i).name for i in range(model.ngeom)]
```
En el ejemplo se accede a la información del modelo de distintas formas.:
	1. La primera accede a los colores de todos los geom. 
	2. La segunda obtiene el id de un *geom* concreto para acceder a sus colores. 
	3. La tercera accede a la estructura de un *geom* por su nombre. 
	4. La cuarta es la tercera pero accediendo a un atributo concreto (el color). 
	5. La quita adquiere los nombres de todo los geom.
El acceso a la información de *data* es equivalente, pero para sus atributos concretos.
Tener en cuenta que el acceso por nombre es propio de los bindings de Python. Para ver los atributos guardados en estas dos estructuras ver: [MJModel](https://mujoco.readthedocs.io/en/latest/APIreference/APItypes.html#mjmodel) y [MJData](https://mujoco.readthedocs.io/en/latest/APIreference/APItypes.html#mjdata) respectivamente.
La información guardada en las estrucutar tambien es modificable, aunque no se recomienda, al menos que sea el input de un actuador (el atributo seria *ctrl* y estaría guardado en *data*).
3. Avanzar la  simulación:
```python
mujoco.mj_forward(model, data)
```
o
```Python
mujoco.mj_step(model, data)
```
La primera opción es recomendable al cargar el modelo, para tener una previsualización.
La segunda se usa para hacer avanzar la simulación. Esta función da un paso físico modificando la clase de *data*. En MuJoCo el tiempo que avanza un paso por defecto es 0.002. Se pueden cambiar en las opciones del modelo.
4. Renderizado. En este caso utilizaremos cv2 para mostrar los frames creados.
```python
import mujoco
import cv2
import math

renderer = mujoco.Renderer(self.model, 480,480)
renderer.update_scene(self.data, camera = "maincamera")
frame = cv2.cvtColor(renderer.render(),cv2.COLOR_BGR2RGB)
cv2.imshow('frame',frame)
cv2.waitKey(0)
cv2.destroyAllWindows()
```
En el ejemplo se utiliza una cámara previamente definida en el *xml* , con nombre *maincamera*.
También se puede utilizar el visualizador.
```python
with mujoco.viewer.launch_passive(cpenv.model, cpenv.data) as viewer:
  # Close the viewer automatically after 30 wall-seconds.
  start = time.time()
  while viewer.is_running() and time.time() - start < 300:
    step_start = time.time()
    #Hacer los pasos deseados
    #...
    # Pick up changes to the physics state, apply perturbations, update options from GUI.
    viewer.sync()
    # Rudimentary time keeping, will drift relative to wall clock.
    time_until_next_step = cpenv.model.opt.timestep - (time.time() - step_start)
    if time_until_next_step > 0:
      time.sleep(time_until_next_step)
```
Es visualizador se puede lanzar normal, o lanzar pasivo. Si se lanza normal el código de python se pausa hasta que se cierre. Si se lanza en modo pasivo el control del viewer lo toma Python y la ejecución continua permitiendo al código hacer modificaciones entre pasos. En el ejemplo se lanza en modo pasivo
## Funcionamiento RL
Para hacer proyecto de RL utilizando mujoco hace falta:
1. Diseñar un modelos de MuJoCo con lenguaje basado en XML. Ver [[MuJoCo XML]]
2. Hacer una clase que sea el entorno, heredada de *gym.Env*, que integre el modelo de MuJoCo *xml*. Ver [[MuJoCo Env]]
